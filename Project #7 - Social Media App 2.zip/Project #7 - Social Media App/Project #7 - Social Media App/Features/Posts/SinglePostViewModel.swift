//
//  SinglePostViewModel.swift
//  Project #7 - Social Media App
//
//  Created by Bridger Mason on 2/13/26.
//

import Foundation

@MainActor
@Observable
final class SinglePostViewModel {
    let post: Post
    private let networkClient: NetworkClientProtocol
    
    var isLiked: Bool = false
    var likeCountDelta: Int = 0
    var isDeleting: Bool = false
    var showDeleteConfirmation: Bool = false
    var deleteErrorMessage: String?
    
    init(post: Post, networkClient: NetworkClientProtocol) {
        self.post = post
        self.networkClient = networkClient
    }
    
    func toggleLike() {
        isLiked.toggle()
        likeCountDelta += isLiked ? 1 : -1
    }
    
    func deletePost(onDeleted: @escaping () -> Void) {
        deleteErrorMessage = nil
        isDeleting = true
        
        Task {
            do {
                try await networkClient.deletePost(postId: post.id)
                await MainActor.run {
                    isDeleting = false
                    onDeleted()
                }
            } catch {
                await MainActor.run {
                    deleteErrorMessage = "Failed to delete post"
                    isDeleting = false
                }
            }
        }
    }
}

