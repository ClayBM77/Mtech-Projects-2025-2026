//
//  TimelineViewModel.swift
//  TSMA
//
//  Created by Nathan Lambson on 11/5/25.
//

import Foundation

@Observable
final class PostsViewModel {
    private(set) var posts: [Post] = []
    private(set) var isLoading: Bool = false
    private(set) var errorMessage: String?

    private let networkClient: NetworkClientProtocol 

    init(networkClient: NetworkClientProtocol) {
        self.networkClient = networkClient
    }

    func load() {
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                let fetched = try await networkClient.fetchPosts(pageNumber: 0)
                posts = fetched.sorted(by: { $0.createdAt > $1.createdAt })
            } catch {
                errorMessage = "Failed to load posts"
            }
        }
    }
}
