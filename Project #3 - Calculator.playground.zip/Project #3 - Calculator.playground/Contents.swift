import UIKit

enum operatorType {
 case add, subtract, multiply, divide, percent, signChange
}
var values: [String] = [""]
var operators: [operatorType] = []

@MainActor func numberButtonPressed(_ num: Int) {
    switch num {
    case 0...9:
        if values.count < operators.count + 1 {
            values.append("0")
        }
        values[operators.count] += String(num)
    default:
        break
    }
}
@MainActor func decimaluttonPressed() {
    if values.count > operators.count {
        if values.count < operators.count + 1 {
            values.append("0")
        }
        if !values[operators.count].contains(".") {
            values[operators.count] += "."
        }
    }
}
@MainActor func invertSignButtonPressed() {
    guard operators.count < values.count else { return }
    if var valuesDouble = Double(values[operators.count]) {
        values[operators.count] = String(valuesDouble * -1)
    }
}
@MainActor func additionButtonPressed() {
    if values.count > operators.count {
        operators.append(.add)
    } else {
        operators.removeLast()
        operators.append(.add)
    }
}
@MainActor func subtractionButtonPressed() {
    if values.count > operators.count {
        operators.append(.subtract)
    } else {
        operators.removeLast()
        operators.append(.subtract)
    }
}
@MainActor func multiplicationButtonPressed() {
    if values.count > operators.count {
        operators.append(.multiply)
    } else {
        operators.removeLast()
        operators.append(.multiply)
    }
}
@MainActor func divisionButtonPressed() {
    if values.count > operators.count {
        operators.append(.divide)
    } else {
        operators.removeLast()
        operators.append(.divide)
    }
}

@MainActor func allClearButtonPressed() {
    values = [""]
    operators = []
}

@MainActor func deleteButtonPressed() {
    if values.count == operators.count {
        operators.removeLast()
    } else {
        if var lastValue = values.last, !lastValue.isEmpty {
            lastValue.removeLast()
            values[values.count - 1] = lastValue
        }
    }
}
@MainActor func equalButtonPressed() -> Double {
    var valuesDouble = values.compactMap { Double($0) }
    var index = 0
    // multiplication/division
    while index < operators.count {
        switch operators[index] {
        case .multiply:
            valuesDouble[index] = valuesDouble[index] * valuesDouble[index + 1]
            valuesDouble.remove(at: index + 1)
            operators.remove(at: index)
        case .divide:
            valuesDouble[index] = valuesDouble[index] / valuesDouble[index + 1]
            valuesDouble.remove(at: index + 1)
            operators.remove(at: index)
        default:
            index += 1
        }
    }
    // Addition/subtraction
    var result = valuesDouble[0]
    for (index, operators) in operators.enumerated() {
        switch operators {
        case .add:
            result += valuesDouble[index + 1]
        case .subtract:
            result -= valuesDouble[index + 1]
        default:
            break
        }
    }
    return result
}



//2/8*3
numberButtonPressed(2)
divisionButtonPressed()
numberButtonPressed(8)
multiplicationButtonPressed()
numberButtonPressed(3)

print(equalButtonPressed())

