import UIKit

enum operatorType {
 case add, subtract, multiply, divide
}
var operatorCount: Int = 0
var values: [String] = [""]
var operators: [operatorType] = []

@MainActor func numberButtonPressed(_ num: Int) {
    switch num {
    case 0...9:
        if values.count < operatorCount + 1 {
            values.append("0")
        }
        values[operatorCount] += String(num)
        default : break
    }
}
@MainActor func additionButtonPressed() {
    guard values.count > operatorCount else { return }
    operators.append(.add)
    operatorCount += 1
}
@MainActor func subtractionButtonPressed() {
    guard values.count > operatorCount else { return }
    operators.append(.subtract)
    operatorCount += 1
}
@MainActor func multiplicationButtonPressed() {
    guard values.count > operatorCount else { return }
    operators.append(.multiply)
    operatorCount += 1
}
@MainActor func divisionButtonPressed() {
    guard values.count > operatorCount else { return }
    operators.append(.divide)
    operatorCount += 1
}

@MainActor func clearButtonPressed() {
    values = [""]
    operatorCount = 0
    operators = []
}

@MainActor func deleteButtonPressed() {
    if values.count == operatorCount {
        operators.removeLast()
        operatorCount -= 1
    } else {
        if var lastValue = values.last, !lastValue.isEmpty {
            lastValue.removeLast()
            values[values.count - 1] = lastValue
        }
    }
}
@MainActor func equalButtonPressed() -> Int {
    // multiplication/division
    var valuesInt = values.compactMap { Int($0) }
    var index = 0
    while index < operators.count {
        switch operators[index] {
        case .multiply:
            valuesInt[index] = valuesInt[index] * valuesInt[index + 1]
            valuesInt.remove(at: index + 1)
            operators.remove(at: index)
        case .divide:
            valuesInt[index] = valuesInt[index] / valuesInt[index + 1]
            valuesInt.remove(at: index + 1)
            operators.remove(at: index)
        default:
            index += 1
        }
    }

    // Addition/subtraction
    var result = valuesInt[0]
    for (index, operators) in operators.enumerated() {
        switch operators {
        case .add:
            result += valuesInt[index + 1]
        case .subtract:
            result -= valuesInt[index + 1]
        default:
            break
        }
    }
    return result
}



numberButtonPressed(1)
numberButtonPressed(2)
deleteButtonPressed()
additionButtonPressed()
multiplicationButtonPressed()
numberButtonPressed(7)
multiplicationButtonPressed()
numberButtonPressed(2)
additionButtonPressed()
multiplicationButtonPressed()
numberButtonPressed(7)
subtractionButtonPressed()
multiplicationButtonPressed()
numberButtonPressed(7)
print(equalButtonPressed())

