import UIKit

enum operatorType {
 case add, subtract, multiply, divide
}
var operatorCount: Int = 0

var value1: Int = 0
var value2: String = ""
var values: [String] = [""]
var operators: [operatorType] = []
@MainActor func numberButtonPressed(_ num: Int) {
    if values.count < operatorCount + 1 {
        values.append("0")
    }
    values[operatorCount] += String(num)
}
@MainActor func operatorButtonPressed(_ buttonPressed: operatorType) {
    guard values.count > operatorCount else { return }
    switch buttonPressed {
    case .add:
        operators.append(.add)
        operatorCount += 1
    case .subtract:
        operators.append(.subtract)
        operatorCount += 1
    case .multiply:
        operators.append(.multiply)
        operatorCount += 1
    case .divide:
        operators.append(.divide)
        operatorCount += 1
        
    }
}
@MainActor func clearButtonPressed() {
    values = [""]
    operatorCount = 0
    operators = []
}
@MainActor func deleteButtonPressed() {
    if values.count == operatorCount {
        operators.removeLast()
        operatorCount -= 1
    } else {
        if var lastValue = values.last, !lastValue.isEmpty {
            lastValue.removeLast()
            values[values.count - 1] = lastValue
        }
    }
}
@MainActor func equalButtonPressed() -> Int {
    // multiplication/division
    var nums = values.compactMap { Int($0) }
    var ops = operators
    var index = 0
    while index < ops.count {
        switch ops[index] {
        case .multiply:
            nums[index] = nums[index] * nums[index + 1]
            nums.remove(at: index + 1)
            ops.remove(at: index)
        case .divide:
            nums[index] = nums[index] / nums[index + 1]
            nums.remove(at: index + 1)
            ops.remove(at: index)
        default:
            index += 1
        }
    }

    // Addition/subtraction
    var result = nums[0]
    for (index, op) in ops.enumerated() {
        switch op {
        case .add:
            result += nums[index + 1]
        case .subtract:
            result -= nums[index + 1]
        default:
            break
        }
    }
    return result
}



numberButtonPressed(1)
numberButtonPressed(2)
operatorButtonPressed(.add)
operatorButtonPressed(.multiply)
numberButtonPressed(7)
operatorButtonPressed(.multiply)
numberButtonPressed(2)
print(equalButtonPressed())

