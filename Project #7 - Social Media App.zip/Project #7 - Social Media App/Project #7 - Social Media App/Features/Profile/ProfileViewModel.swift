//
//  ProfileViewModel.swift
//  Project #7 - Social Media App
//
//  Created by Bridger Mason on 11/17/25.
//

import Foundation
import SwiftUI
import Combine

@MainActor
final class ProfileViewModel: ObservableObject {
    @Published var user: User?
    @Published var errorMessage: String?
    @Published var currentUserPost: Post? 
    // @Published var

    private let repository: UserRepositoryProtocol
    
    private let networkClient: NetworkClientProtocol
    
    private(set) var posts: [Post] = []
    private(set) var isLoading: Bool = false
    

    

    init(networkClient: NetworkClientProtocol, repository: UserRepositoryProtocol) {
        self.networkClient = networkClient
        self.repository = repository
    }

    func load() async {
        print("load hit")
        do {
            self.user = try await repository.fetchCurrentUser()
        } catch {
            self.errorMessage = error.localizedDescription
            print(errorMessage as Any)
        }
        
        Task {
            isLoading = true
            defer { isLoading = false }
            do { posts = try await networkClient.fetchPosts(pageNumber: 0) }
            catch { errorMessage = "Failed to load posts" }
        }
        
    }
    func fetchCurrentUserPost(_ user: User) {
        self.currentUserPost = Post(id: "p1",
                 author: user,
                 title: "Welcome",
                 body: "This is the first sample post.",
                 likeCount: 12,
                 commentCount: 3,
                 createdAt: .now)
        
    }
}
