//
//  ProfileView.swift
//  TSMA
//
//  Created by Nathan Lambson on 11/5/25.
//

/*
A **user profile page** tab.
    - This screen should show the **currently logged in user**.
    - It should show a **profile photo** and a **background (cover) photo** at the top of the screen.
    - It should show the user's **first name, last name, username, bio, and tech interests**. Since this app is designed for Tech Industry workers, the tech interests is a place for them to specifically list the topics that they are interested in.
    - It should have **at least one post** (representing the most recent user post) under the user details.
*/

import SwiftUI

struct ProfileView: View {
    
    @StateObject private var viewModel: ProfileViewModel
    @State private var isShowingEditProfile = false
    @State private var isShowingNewPostSheet = false
    
    
    @State private var draftTitle: String = ""
    @State private var draftBody: String = ""
    
    init(repository: UserRepositoryProtocol = MockUserRepository(), networkClient: NetworkClientProtocol = MockNetworkClient()) {
        _viewModel = StateObject(
            wrappedValue: ProfileViewModel(networkClient: networkClient, repository: repository)
        )
    }
    
    var body: some View {
        
        NavigationStack {
            VStack {
                
                ZStack(alignment: .bottom) {
                    
                    
                    if let url = viewModel.user?.coverImageURL {
                        AsyncImage(url: url) { image in
                            image
                                .resizable()
                                .scaledToFill()
                        } placeholder: {
                            Color.gray.opacity(0.2)
                        }
                        .frame(maxWidth: .infinity, maxHeight: 180)
                        .clipped()
                        .ignoresSafeArea(.all)
                    } else {
                        // Fallback if no URL yet
                        Color.gray.opacity(0.2)
                            .frame(maxWidth: .infinity, maxHeight: 160)
                        
                    }
                    
                    
                    HStack(alignment: .center) {
                        
                        if let url = viewModel.user?.profileImageURL {
                            AsyncImage(url: url) { image in
                                image
                                    .resizable()
                                    .scaledToFill()
                            } placeholder: {
                                Color.gray.opacity(0.2)
                            }
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(.white, lineWidth: 3))
                            .shadow(radius: 6)
                            
                            .padding(.leading)
                        }
                        VStack {
                            Text(
                                "\(viewModel.user?.firstName ?? "") \(viewModel.user?.lastName ?? "")"
                            )
                            Text(viewModel.user?.biography ?? "")
                            
                        }
                        
                        
                        Spacer()
                    }
                    
                    
                }
                HStack {
                    Spacer()
                    VStack {
                        Text("Interests: ")
                        ForEach(viewModel.user?.techInterests ?? [], id: \.self) { interest in
                            Text(interest)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .padding(.vertical, 2)
                        }
                    }
                    Spacer()
                }
                
                .glassEffect()
               
                if let post = viewModel.currentUserPost {
                    PostRowView(post: post)
                }
                
                Spacer()
                Button("New Post") {
                    isShowingNewPostSheet = true
                }
                .padding()
                .glassEffect()
                .sheet(isPresented: $isShowingNewPostSheet) {
                    NavigationStack {
                        

                        Form {
                            Section(header: Text("Title")) {
                                TextField("What's on your mind?", text: $draftTitle)
                            }
                            Section(header: Text("Body")) {
                                TextEditor(text: $draftBody)
                                    .frame(minHeight: 160)
                            }
                            
                        }
                        .navigationTitle("New Post")
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) {
                                Button("Discard") {
                                    draftTitle = ""
                                    draftBody = ""
                                    isShowingNewPostSheet = false
                                }
                            }
                            ToolbarItem(placement: .confirmationAction) {
                                Button("Save Draft") {
                                    
                                    isShowingNewPostSheet = false
                                }
                                
                            }
                        }
                    }
                }
                
            }
                
            .background(
                LinearGradient(
                    colors: [.white, .white, .white, .white, .gray],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
                 
            .toolbar {
                ToolbarItem {
                    Button("Edit Profile") {
                        isShowingEditProfile = true
                    }
                }
            }
            .sheet(isPresented: $isShowingEditProfile) {
                NavigationStack {
                    Form {
                        Section(header: Text("Name")) {
                            TextField("First Name", text: Binding(
                                get: { viewModel.user?.firstName ?? "" },
                                set: { _,_ in }
                            ))
                            TextField("Last Name", text: Binding(
                                get: { viewModel.user?.lastName ?? "" },
                                set: { _,_ in }
                            ))
                            TextField("Username", text: Binding(
                                get: { viewModel.user?.userName ?? "" },
                                set: { _,_ in }
                            ))
                        }
                        Section(header: Text("Bio")) {
                            TextEditor(text: Binding(
                                get: { viewModel.user?.biography ?? "" },
                                set: { _,_ in }
                            ))
                            .frame(minHeight: 120)
                        }
                        Section(header: Text("Tech Interests (comma-separated)")) {
                            TextField("e.g. Swift, SwiftUI, AI", text: Binding(
                                get: { (viewModel.user?.techInterests ?? []).joined(separator: ", ") },
                                set: { _,_ in }
                            ))
                        }
                    }
                    .navigationTitle("Edit Profile")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Cancel") { isShowingEditProfile = false }
                        }
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Done") {
                                isShowingEditProfile = false
                            }
                        }
                    }
                }
            }
            .task {
                await viewModel.load()
                
                    }
            .task(id: viewModel.user?.id) {
                if let user: User = viewModel.user {
                     viewModel.fetchCurrentUserPost(viewModel.user! )
                }
            }
            }
                
            }
        }
    

#Preview {
    ProfileView()
}
