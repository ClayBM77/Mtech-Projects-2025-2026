//
//  PostsRowView.swift
//  TSMA
//
//  Created by Nathan Lambson on 11/5/25.
//

import SwiftUI

struct PostRowView: View {
    let post: Post
    @State private var isLiked = false
    @State private var likeCountDelta = 0
    @State private var showingComments = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("\(post.author.firstName) \(post.author.lastName) • \(post.author.userName)")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Text(post.title)
                .font(.headline)

            Text(post.body)
                .font(.body)

            HStack(spacing: 16) {
                Button {
                    isLiked.toggle()
                    likeCountDelta += isLiked ? 1 : -1
                } label: {
                    Label("\(post.likeCount + likeCountDelta)",
                          systemImage: isLiked ? "hand.thumbsup.fill" : "hand.thumbsup")
                    .contentShape(Rectangle())
                    .buttonStyle(.plain)
                }
                
                Button("\(post.commentCount)", systemImage: "text.bubble") {
                    
                    showingComments = true
                    
                }
                .contentShape(Rectangle())
                .buttonStyle(.plain)
            }
            .font(.footnote)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 8)
        .sheet(isPresented: $showingComments) {     // 3) present sheet
            // Replace with your real comments UI
            CommentsView(post: post)                 // e.g., a dedicated view
                .presentationDetents([.medium, .large]) // optional
        }
    }
}

#if DEBUG
extension User {
    static let sample = User(id: "u_dbg", firstName: "Ada", lastName: "Lovelace", userName: "ada", biography: "Poet of numbers", techInterests: ["Swift","UI"], profileImageURL: nil, coverImageURL: nil)
}
extension Post {
    static let sample = Post(id: "p_dbg", author: .sample, title: "Sample", body: "Preview content", likeCount: 1, commentCount: 0, createdAt: .now)
}
#Preview {
    PostRowView(post: .sample)
}
#endif
