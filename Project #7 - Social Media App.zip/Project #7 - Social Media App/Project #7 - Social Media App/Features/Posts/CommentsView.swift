//
//  Comments.swift
//  Project #7 - Social Media App
//
//  Created by Bridger Mason on 11/18/25.
//

import SwiftUI 

struct CommentsView: View {
    let post: Post
    var body: some View {
        NavigationStack {
            Text("Comments for: \(post.title)")
                .padding()
                .navigationTitle("Comments")
        }
    }
}
