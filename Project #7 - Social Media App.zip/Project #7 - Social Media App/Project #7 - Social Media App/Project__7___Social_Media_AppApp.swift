//___FILEHEADER___

import SwiftUI

@main
struct Project7: App {
    
    @State private var appServices = AppServices(
        networkClient: MockNetworkClient(),
        userRepository: MockUserRepository()
    )

    
    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environment(appServices)
        }
    }
}
