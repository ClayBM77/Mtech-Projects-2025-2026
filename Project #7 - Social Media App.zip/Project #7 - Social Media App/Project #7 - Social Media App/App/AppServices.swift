//
//  AppServices.swift
//  Project #7 - Social Media App
//
//  Created by Bridger Mason on 11/17/25.
//

import Foundation
import Combine

@Observable
final class AppServices {
    private(set) var isReady: Bool = true

    let networkClient: NetworkClientProtocol
    let userRepository: UserRepositoryProtocol

    init(networkClient: NetworkClientProtocol, userRepository: UserRepositoryProtocol) {
        self.networkClient = networkClient
        self.userRepository = userRepository
    }
}
